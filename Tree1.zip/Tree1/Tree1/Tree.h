#pragma once
#ifndef INCLUDE_NODE_H
#define INCLUDE_NODE_H

//Vector from STL
#include<vector>

using namespace std;

//Node class to store each node on the tree
class node
{
public:
	vector< node*> children;		// a vector to store the children of the node
	std::vector<node*>::iterator it;	//iterator
	node *parent;			//stores the parent of the node
	int data;				//stores data on each node
	void printNode(int level);	//prints the node value 

};

//Node tree to make the tree
class tree
{
public:
	vector<node*> tr;		// a vector of all the tree nodes
	node* root;				//root stores the value of the first element in the tree
	int numOfTreeElements=0;	//the variable contains the number of elements in the tree
	void insert( int ele, int m);	// this is used to insert an element in the tree
	void printTree(int level);	//this is used to print the tree
};
void  tree::insert(int ele, int m) {
	
	//makes a new node element 
	node *n = new node;						
	n->data = ele;			//intializes the element to thr data
	if (numOfTreeElements == 0)			//if there is no node it creates the first node which is the root
	{										
		tr.push_back(n);			//pushes the element on the vector
		n->parent = NULL;			//the root node parent is NULL
		numOfTreeElements++;		//the number of elements increases
		root = n;				
	}
	else                       //this creates nodes if there are already nodes present
	{
		tr.push_back(n);		//pushes the element on the vector
		n->parent = tr[(numOfTreeElements - 1) / m];  //the parent is present on the (i-1)/m index where i is the index of current node
		//the above statement is used to assign the parent to the correct index 
		tr[(numOfTreeElements - 1) / m]->children.push_back(n); //this pushes the element on the child vector of the node
		numOfTreeElements++;		//the total number of elements increases
	}

}

//This function is used to print each node. This is a reccursive function used for printing
void node::printNode(int level)
{
	cout << "Level = " << level << "    "; // prints at what level the node is present at
	cout << "Node value = " << data << "      ";	//prints the value of the node
	cout << "Parent = ";	//prints the parent of the node
	if (parent == NULL)// checks if the node is the root
		cout << "ROOT";
	else
		cout << parent->data;
	cout << "        Children = ";		

	for (int i = 0; i < children.size(); i++)//prints the children present in each node
	{
		cout << children[i]->data << " "; 
	}
	level++; //increases the level each time 
	cout << endl;
	for (int i = 0; i < children.size(); i++)
	{
		children[i]->printNode(level); //recurrively calls the function to print the children for each parent 
	}
	
}
//Called to print the tree
void tree::printTree(int level)
{
	root->printNode(0); //prints the tree passing the intial level as 0
}

#endif
