//C++ Library Header Files
#include <iostream>

//User declared header files
#include"Tree.h"

using namespace std;

//main function 
int main(int argc, char** argv) {
	
	int m,n, ctr=100 ; 
	m = 3; 
	n = 10;			//a computer run program that creates a 3-mary tree with 10 elements
	
	cout << "Computer Sitmulated Program "<<endl;
	tree t;
	for (int i = 0; i < n; i++)
	{
		t.insert(ctr, m);			//this inserts number on the tree in reverse order starting from 100
		ctr--;
	}
	t.printTree(0); //prints the tree 
	//tree created by the user
	cout << endl << endl << "The above is a tree with m = 3 and n=10. Now your turn to input m " << endl;
	cout << "Enter the value of m for your m-ary tree ";			//ask the user to input m for m-mary tree
	cin >> m;
	cout << "Enter the number of elements you want to insert ";		//enters the number of elements in the tree
	cin >> n;
	ctr = 100;
	tree t1;
	ctr = 100;
	for (int i = 0; i < n; i++)
	{
		t1.insert(ctr,m);		//this inserts number on the tree in reverse order starting from 100
		ctr--;
	}
	t1.printTree(0);		//prints the tree
}